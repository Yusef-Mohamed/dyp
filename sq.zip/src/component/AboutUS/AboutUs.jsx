import React from "react";
import "./aboutus.css";
function AboutUs() {
  return (
    <div className="bg-white">
      <div className="aboutImg">1</div>
      <div className="container my-5">
        <h1 className="text-center my-5">About Us</h1>
        <p style={{ lineHeight: "1.8" }}>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui pariatur
          numquam iusto sed, id necessitatibus tempora voluptate nemo facere
          nostrum eaque officiis incidunt eligendi debitis corporis quidem unde
          saepe accusamus! Lorem ipsum dolor sit amet consectetur adipisicing
          elit. Iste placeat consequuntur eos autem, temporibus distinctio
          voluptates, necessitatibus quod eius officiis molestiae quos minima ex
          est. Laborum sunt rem dicta officia. Lorem ipsum dolor sit amet
          consectetur, adipisicing elit. Aperiam amet dolorum reiciendis, ullam
          obcaecati nulla impedit dignissimos odio vero quis. Nihil labore
          quaerat delectus saepe tempora odit voluptas eligendi quibusdam.
        </p>
      </div>
    </div>
  );
}

export default AboutUs;
